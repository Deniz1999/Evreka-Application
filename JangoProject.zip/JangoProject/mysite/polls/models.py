from django.db import models
import datetime


class Vehicle(models.Model):
    plate = models.CharField(max_length=200)

class NavigationRecord(models.Model):
    vehicle = models.ForeignKey(Vehicle,on_delete=models.CASCADE)
    datetime = models.DateTimeField(default=datetime.datetime.now()) 
    latitude = models.FloatField(max_length=200)
    longitude = models.FloatField(max_length=200)
    pub_date = models.DateTimeField('date published')s


# Suggestions made: 

# I would also suggest creating a table containing the records/rows that happened in the last 48 hours
# Every time I would want to retrieve these records, an update function will be called which handles dropping records that happened more than 48 hours ago. 
# New records will be added automatically to a new table containing the records that occurred 48 years ago
# This is a technique that can be applied to data warehousing where the main priority is not normalising the data but instead we are optimising the table structure for a fast and efficient data retrieval. 
# This is more efficient because in the function provided, I look at all the records/rows in the database whereas using the method I suggested we would only have to retrieve a small number of records which are the ones that happened in the past 48 hours. 