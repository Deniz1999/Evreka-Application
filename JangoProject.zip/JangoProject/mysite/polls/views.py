from django.http import HttpResponse
from polls.models import NavigationRecord, Vehicle
import datetime

def index(request):
    return HttpResponse("Hello, world. You're at the polls index.")

def get_vehicles_for_48_hours(request):
	cars  =  Vehicle.objects.all() # Gets all vehicles 
	fourty_eight_hours_ago = datetime.datetime.now() - datetime.timedelta(hours=48) # Time 48 hours ago
	print(fourty_eight_hours_ago)
	last_points = [] #array to store all vehcle points
	for car in cars:
		point = {}
		All_Vehicle_Navigation_Records = NavigationRecord.objects.filter(vehicle=car) #all navigation records for that car
		past_48_hours = All_Vehicle_Navigation_Records.filter(datetime__gte = fourty_eight_hours_ago) # Gets all the records that happened between 48 hours ago and datetime.now() 
		for record in past_48_hours: #Each record that vehicle has in the past 48 hours
			point["latitude"] = record.latitude
			point["longitude"] = record.longitude
			point["vehicle_plate"] = record.vehicle.plate
			point["datetime"] = record.datetime.strftime("%m/%d/%Y, %H:%M:%S")
			last_points.append(point)
	print(last_points)
	return HttpResponse(last_points)



