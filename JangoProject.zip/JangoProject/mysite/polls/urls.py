from django.contrib import admin
from django.urls import include, path

from . import views 

urlpatterns = [
	path('', views.index, name = 'index'),
	path('get_vehicles/',views.get_vehicles_for_48_hours,name='get_vehicles_for_48_hours')
]