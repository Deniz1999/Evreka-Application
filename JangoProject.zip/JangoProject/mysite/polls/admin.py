from django.contrib import admin
from .models import Vehicle, NavigationRecord

admin.site.register(Vehicle)
admin.site.register(NavigationRecord)

# Register your models here.
